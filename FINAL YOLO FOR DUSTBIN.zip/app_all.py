"""
BinGo web page: upload a disposal video -> watch the result video (bin box + bin-type banner + verdict)
and see the disposal evidence table AND the bin type (official / local) with its score.

Put in one folder: best.pt  bin_type.pt  verify.py  bin_type.py  bin_type_video.py  run_all.py  app_all.py
Run:
    py app_all.py
It opens http://127.0.0.1:7860 in your browser by itself.
Set BINGO_SHARE=1 for a public link you can open on your phone.
"""
import os
import tempfile

import gradio as gr

import run_all as RA

ICON = {"approved": "✅ Approved", "review": "🟡 Needs review", "rejected": "❌ Not verified"}
tick = lambda v: "✅" if v >= 0.7 else ("🟡" if v >= 0.3 else "❌")


def evidence_md(p):
    """Evidence table. Works with both versions of verify.py."""
    if "hand" in p:                                   # newer verify.py: weighted evidence
        when = f" (seen {p['first_s']} s to {p['last_s']} s)" if p.get("first_s") is not None else ""
        return (
            "| Evidence | Result | Weight |\n|---|---|---|\n"
            f"| Object taken from a hand | {tick(p['hand'])} {p['hand']:.2f} | 25% |\n"
            f"| Object clearly seen outside the bin | {tick(p['outside'])} {p['outside']:.2f} | 15% |\n"
            f"| Its path moved towards the bin | {tick(p['approach'])} {p['approach']:.2f} | 15% |\n"
            f"| Path ended inside the bin{when} | {tick(p['entry'])} {p['entry']:.2f} | 25% |\n"
            f"| Nothing left outside afterwards | {tick(p['gone'])} {p['gone']:.2f} | 10% |\n"
            f"| Bin found + camera steady | {tick(p['steady'])} {p['steady']:.2f} | 10% |\n\n"
            f"Bin found in {p['bin_found'] * 100:.0f}% of frames, shaky frames {p['shaky'] * 100:.0f}%.")
    rows = ["| Evidence | Value |", "|---|---|"]           # original verify.py: flat details
    names = {"object_id": "Tracked object id", "start_s": "Object first seen (s)", "end_s": "Object last seen (s)",
             "bin_presence": "Bin found in share of frames", "bin_changed": "Bin area change start to end"}
    for k, v in p.items():
        rows.append(f"| {names.get(k, k)} | {v} |")
    return "\n".join(rows)


def run(video_path, bin_text):
    if not video_path:
        return None, "Upload a video first."
    try:
        out = os.path.join(tempfile.mkdtemp(prefix="bingo_all_"), "result.mp4")
        r = RA.run_all(video_path, out_path=out, stride=3, bin_text=bin_text or None)
    except Exception as e:  # show the problem in the page instead of crashing
        return None, f"**Error:** {e}"

    d, b = r["disposal"], r["bin"]
    p = RA.evidence(d)
    if b is None:
        bin_md = "### Bin type\nNot checked, because no bin was found in the video."
    else:
        kind = "🟢 **OFFICIAL public bin**" if b.get("official") else "🟠 **Local bin** (not an official public bin)"
        probs = " | ".join(f"{k.replace('_', ' ')} {v:.2f}" for k, v in b["probs"].items())
        bin_md = (f"### Bin type\n{kind}: {b['label']}, bin score **{b['score']}**\n\n"
                  f"Model confidence per type: {probs}")

    md = (
        f"## {ICON[r['status']]}  (final score {r['final']})\n"
        f"Final = {int(RA.W_DISPOSAL * 100)}% disposal check + {int(RA.W_BIN * 100)}% bin score. "
        "A rejected throw always stays rejected.\n\n"
        f"{bin_md}\n\n"
        f"### Disposal check: {ICON[d['status']]} (score {d['conf']})\n{d['message']}\n\n"
        f"{evidence_md(p)}\n\n"
        "*Verification is AI-assisted and probabilistic.*"
    )
    return r["out_path"], md


with gr.Blocks(title="BinGo") as demo:
    gr.Markdown("# BinGo\nUpload a short video of someone throwing an item into a bin. It checks the throw "
                "**and** tells you whether the bin is an official public bin or a local bin. Keep the phone steady.")
    with gr.Row():
        inp = gr.Video(label="Your video (4-30 s)", sources=["upload"])
        out = gr.Video(label="Result video (bin box, bin type, verdict)", autoplay=True)
    bin_in = gr.Textbox(label="Bin region (optional, only if the bin is not detected)",
                        placeholder="x1,y1,x2,y2 in percent, e.g. 25,45,80,95")
    btn = gr.Button("Verify", variant="primary")
    verdict = gr.Markdown()
    btn.click(run, [inp, bin_in], [out, verdict])

if __name__ == "__main__":
    demo.launch(share=os.environ.get("BINGO_SHARE") == "1", inbrowser=True)
